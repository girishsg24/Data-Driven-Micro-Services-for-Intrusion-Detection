
void console_handle_input(evtchn_port_t port, struct pt_regs *regs, void *data);
