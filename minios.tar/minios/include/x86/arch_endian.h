#ifndef	ARCH_ENDIAN_H
#error "Do not include arch_endian by itself, include endian.h"
#else

#define __BYTE_ORDER __LITTLE_ENDIAN

#endif
