#define __WORDSIZE 32
