#ifndef _LINUX_TYPES_H_
#define _LINUX_TYPES_H_
#include <mini-os/types.h>
typedef uint64_t __u64;
#endif /* _LINUX_TYPES_H_ */
